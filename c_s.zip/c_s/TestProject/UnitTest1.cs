using Xunit;
using MJU23v_D15_inl_todolist;

namespace MJU23v_D15_inl_todolist.Tests
{
    public class TodoItemTests
    {
        [Fact]
        public void TodoItem_FirstConstructor_CreateObjectWithTwoArguments()
        {
            // Arrange
            int priority = 1;
            string task = "Sample Task";

            // Act
            Todo.TodoItem item = new Todo.TodoItem(priority, task);

            // Assert
            Assert.NotNull(item);
            Assert.Equal(priority, item.priority);
            Assert.Equal(task, item.task);
        }

        [Fact]
        public void TodoItem_SecondConstructor_CreateObjectWithTodoLineArgument()
        {
            // Arrange
            string todoLine = "2|1|Sample Task|Sample Description";

            // Act
            Todo.TodoItem item = new Todo.TodoItem(todoLine);

            // Assert
            Assert.NotNull(item);
            Assert.Equal(Todo.TodoItem.Waiting, item.status);
            Assert.Equal("Sample Task", item.task);
            Assert.Equal("Sample Description", item.taskDescription);
        }

        [Fact]
        public void TodoItem_ToString_ReturnStringRepresentationWithoutVerbose()
        {
            // Arrange
            int priority = 1;
            string task = "Sample Task";
            string expected = "|aktiv       |1     |Sample Task         |";

            // Act
            Todo.TodoItem item = new Todo.TodoItem(priority, task);
            string result = item.ToString(verbose: false);

            // Assert
            Assert.Equal(expected, result);
        }

        [Fact]
        public void TodoItem_ToString_ReturnStringRepresentationWithVerbose()
        {
            // Arrange
            int priority = 1;
            string task = "Sample Task";
            string taskDescription = "Sample Description";
            string expected = "|aktiv       |1     |Sample Task         |Sample Description                      |";

            // Act
            Todo.TodoItem item = new Todo.TodoItem(priority, task);
            item.taskDescription = taskDescription;
            string result = item.ToString(verbose: true);

            // Print expected and actual strings
            Console.WriteLine("Expected: " + expected);
            Console.WriteLine("Actual:   " + result);

            // Assert
            Assert.Equal(expected, result, ignoreLineEndingDifferences: true);
        }



        [Fact]
        public void TodoItem_SetActive_ChangeStatusToActive()
        {
            // Arrange
            Todo.TodoItem item = new Todo.TodoItem(1, "Sample Task");
            item.status = Todo.TodoItem.Waiting;

            // Act
            bool result = item.SetActive();

            // Assert
            Assert.True(result);
            Assert.Equal(Todo.TodoItem.Active, item.status);
        }

        [Fact]
        public void TodoItem_SetActive_ReturnFalseIfStatusIsNotWaiting()
        {
            // Arrange
            Todo.TodoItem item = new Todo.TodoItem(1, "Sample Task");
            item.status = Todo.TodoItem.Active;

            // Act
            bool result = item.SetActive();

            // Assert
            Assert.False(result);
            Assert.Equal(Todo.TodoItem.Active, item.status);
        }

        [Fact]
        public void TodoItem_SetReady_ChangeStatusToReady()
        {
            // Arrange
            Todo.TodoItem item = new Todo.TodoItem(1, "Sample Task");
            item.status = Todo.TodoItem.Active;

            // Act
            bool result = item.SetReady();

            // Assert
            Assert.True(result);
            Assert.Equal(Todo.TodoItem.Ready, item.status);
        }

                [Fact]
        public void TodoItem_SetReady_ReturnFalseIfStatusIsNotActive()
        {
            // Arrange
            Todo.TodoItem item = new Todo.TodoItem(1, "Sample Task");
            item.status = Todo.TodoItem.Ready;

            // Act
            bool result = item.SetReady();

            // Assert
            Assert.False(result);
            Assert.Equal(Todo.TodoItem.Ready, item.status);
        }

        [Fact]
        public void TodoItem_SetWaiting_ChangeStatusToWaiting()
        {
            // Arrange
            Todo.TodoItem item = new Todo.TodoItem(1, "Sample Task");
            item.status = Todo.TodoItem.Active;

            // Act
            bool result = item.SetWaiting();

            // Assert
            Assert.True(result);
            Assert.Equal(Todo.TodoItem.Waiting, item.status);
        }

        [Fact]
        public void TodoItem_SetWaiting_ReturnFalseIfStatusIsNotActive()
        {
            // Arrange
            Todo.TodoItem item = new Todo.TodoItem(1, "Sample Task");
            item.status = Todo.TodoItem.Waiting;

            // Act
            bool result = item.SetWaiting();

            // Assert
            Assert.False(result);
            Assert.Equal(Todo.TodoItem.Waiting, item.status);
        }
        [Fact]
        public void TodoItem_SetStatusToReady_ReturnFalseWhenStatusIsReady()
        {
            // Arrange
            Todo.TodoItem item = new Todo.TodoItem(1, "Sample Task");
            item.status = Todo.TodoItem.Ready;

            // Act
            bool result = item.SetStatus(Todo.TodoItem.Ready);

            // Assert
            Assert.False(result);
            Assert.Equal(Todo.TodoItem.Ready, item.status);
        }

        [Fact]
        public void TodoItem_StatusString_ReturnsActiveString()
        {
            // Arrange
            Todo.TodoItem item = new Todo.TodoItem(1, "Sample Task");
            item.status = Todo.TodoItem.Active;
            string expected = "aktiv";

            // Act
            string result = item.StatusString();

            // Assert
            Assert.Equal(expected, result);
        }
    }
}

